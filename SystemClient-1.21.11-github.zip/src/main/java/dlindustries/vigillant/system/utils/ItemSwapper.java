package dlindustries.vigillant.system.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

import java.util.function.ToIntFunction;

/**
 * Puts a wanted item into the player's hand and puts everything back afterwards.
 *
 * HandSwap: the wanted item (hotbar OR inventory) is swapped with whatever is in the held slot
 *           and swapped back on restore(), so the item you held comes back to the same slot.
 * Hotbar:   only changes the selected hotbar slot (wanted item must be in the hotbar).
 */
public final class ItemSwapper {
	public enum Mode {
		HandSwap("Hand Swap"),
		Hotbar("Hotbar");

		private final String label;

		Mode(String label) {
			this.label = label;
		}

		@Override
		public String toString() {
			return label;
		}
	}

	private final MinecraftClient mc = MinecraftClient.getInstance();

	private boolean active;
	private Mode usedMode;
	private int previousSlot = -1;
	private int clickSlotId = -1;

	public boolean isActive() {
		return active;
	}

	/**
	 * @param scorer returns -1 for items that are not wanted, otherwise a score (higher = better)
	 * @return true if a wanted item is in the hand afterwards
	 */
	public boolean equip(ToIntFunction<ItemStack> scorer, Mode mode) {
		if (mc.player == null || mc.interactionManager == null) return false;
		if (active) return true;

		PlayerInventory inv = mc.player.getInventory();
		int current = InventoryUtils.getSelectedSlot();

		// already holding the wanted item, nothing to swap
		if (scorer.applyAsInt(inv.getStack(current)) >= 0) return true;

		int best = -1;
		int bestScore = -1;
		int limit = mode == Mode.Hotbar ? 9 : 36;
		for (int i = 0; i < limit; i++) {
			int score = scorer.applyAsInt(inv.getStack(i));
			if (score > bestScore) {
				bestScore = score;
				best = i;
			}
		}
		if (best == -1) return false;

		previousSlot = current;
		usedMode = mode;

		if (mode == Mode.Hotbar) {
			InventoryUtils.setSelectedSlot(best);
		} else {
			// screen handler ids: hotbar 36-44, main inventory 9-35
			clickSlotId = best < 9 ? 36 + best : best;
			swapWithHand(clickSlotId, current);
		}

		active = true;
		return true;
	}

	/** Puts the original item back. */
	public void restore() {
		if (!active) return;
		active = false;

		if (mc.player == null || mc.interactionManager == null) return;

		if (usedMode == Mode.Hotbar) {
			InventoryUtils.setSelectedSlot(previousSlot);
		} else {
			swapWithHand(clickSlotId, previousSlot);
		}
	}

	/** Forget the swap without restoring (item stays in hand). */
	public void clear() {
		active = false;
	}

	private void swapWithHand(int slotId, int hotbarButton) {
		mc.interactionManager.clickSlot(
				mc.player.playerScreenHandler.syncId,
				slotId,
				hotbarButton,
				SlotActionType.SWAP,
				mc.player
		);
	}
}
